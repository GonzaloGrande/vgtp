#!/bin/bash
 
# Dirección de correo electrónico del usuario root
correo="vg_tp@hotmail.com"

for proceso in "$@"; do
   if ! pgrep "$proceso" >/dev/null; then
# El proceso no está en ejecución, se envia un correo electrónico
    echo "El proceso $proceso no se encuentra en ejecución."
    echo "El proceso $proceso no se encuentra en ejecución." |mutt -s "Alerta de monitoreo" "$correo" #Se envia con el Gmail creado tarda un toque
    echo "El proceso $proceso no se encuentra en ejecución."|mail -s "Alerta de monitoreo" debian1 #Se envia con postfix  
   else echo "El $proceso se encuentra en ejecucion."
fi
done
