#!/bin/bash

# Función de ayuda
function show_help {
        echo "Uso: $(basename $0) <directorio_origen> <directorio_destino>"
}

# Funcion que indica que falta argumento
function falta_argumento {
        echo "ERROR de argumento: debe ingresar 2 directorios"
        show_help
        exit 1
}

# Funcion que indica si el directorio es invalido o no esta montado
function directorio_invalido {
        echo "ERROR: directorio $1 invalido o no esta montado"
        show_help
        exit 1
}

# Función para verificar si un directorio está montado
function esta_montado {
    local dir="$1"
    if sudo  mountpoint -q "$dir"; then
        return 0 # Montado
    else
        return 1 # No montado
    fi
}

# Agrega una línea en el archivo recibido en $1, concatenando hora, minutos, segundos y el mensaje recibido en $2.
function log {
   TIME=$(date +"%T")
   echo "$TIME - $2" |tee -a $1
 }

# Directorios de origen y destino
origen="$1"
destino="$2"

# Valida si los directorios existen
if [ -z $origen ]; then
         falta_argumento "origen"
elif [ $origen = "-h" ] && [ $# -ne 1 ]; then
        show_help
        exit 0
elif [ -z $destino ]; then
        falta_argumento "destino"
elif ! esta_montado "$origen"; then
	if [ ! -d "$origen" ]; then
	directorio_invalido $1
   	fi
elif ! esta_montado "$destino"; then
	if [ ! -d "$destino" ]; then
        directorio_invalido $2
	fi
fi

# Se crean variables con los nombres de los archivos.
NOW=$(date +'%Y%m%d')
DESTINO_FILE="${destino}${origen}_bkp_${NOW}.tar.gz"
LOG_FILE="${destino}${origen}_bkp_${NOW}.log"

# Se crea el archivo de log si no existe.
touch $LOG_FILE

# Se vacía el archivo log que de esta ejecución.
cat /dev/null > $LOG_FILE

# Se loguea el estado del proceso.
log $LOG_FILE "Inicia el proceso de backup."
log $LOG_FILE "ARCHIVO DESTINO: $DESTINO_FILE."
log $LOG_FILE "Archivo Log: $LOG_FILE."
log $LOG_FILE "Comprimiendo archivo: "

# Se realiza el backup y se deja el output en el log.
tar cvzf $DESTINO_FILE $1 | tee -a $LOG_FILE

log $LOG_FILE "Proceso finalizado "

#Crea la variable correo para asignar el mail de root
correo="vg_tp@hotmail.com"

# Enviar el log al usuario root a través de correo local. Se creo el vg_tp@hotmail.com para recibir mails a root y vgtp2023@gmail.com para enviar mail por mutt
#mutt -s "Log de backup.sh"  "$correo" < "$LOG_FILE"
#Tambien utilizamos postfix para hacer un mail interno a root
mail -s "Log de backup.sh" debian1 < "$LOG_FILE"

exit 0
