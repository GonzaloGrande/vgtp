#!/bin/bash

 fecha=$1

 function esLaborable {

 #Dia de la semana de 0 a 6 (0 = Domingo)
 dia1=$(date -d "$fecha" +%w)


 #Asignamos dia y mes para comparar contra la base de datos feriados.txt
 dia2=$(date -d "$fecha" +"%m/%d")

 #Comparamos
 feriados=$(cat /opt/tp/scripts/feriados.txt | grep -w "$dia2")

 #Revisamos que no sea fin de semana (Sabado o Domingo)
 if [ "$dia1" = 6 ]; then
     echo "Sabado, es no laborable"
 elif [ "$dia1" = 0 ]; then
      echo "Domingo, es no laborable"
 # Revisamos que no sea feriado
 elif [ "$feriados" ]; then
   echo "Es feriado, no laborable."
 # Si no es feriado ni fin de semana es laborable
 else
      echo "Es laborable >:^("
 fi

 }

 esLaborable "$1"
 exit
