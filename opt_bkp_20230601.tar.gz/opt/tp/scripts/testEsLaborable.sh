 #!/bin/bash

 # Obterner la fecha del argumento
 fecha=$1

 # Verificar número de argumentos
 if [ $# -ne 1 ]; then
         echo "Debe tener un solo argumento: $0 <fecha> (YYYY/MM/DD)"
         exit 1
 
 # Verificar el formato de la fecha. Se utiliza el comando date -d "$fecha" +"%d/%m/%Y" para formatear la fecha ingresada en el formato "DD/MM/YYYY". Luego, se compara el resultado con la fecha ingresada original. Si el resultad    o no coincide con la fecha original, significa que la fecha ingresada no es válida.

 elif ! date -d "$fecha" +"%Y/%m/%d" >/dev/null 2>&1; then
         echo "Fecha inválida. Formato esperado:YYYY/MM/DD"
         exit 1
# La fecha tiene un formato válido

 else  echo "La fecha $fecha es válida."
   # Pasar la fecha como argumento al otro script
  /opt/tp/scripts/esLaborable.sh "$fecha"
fi
